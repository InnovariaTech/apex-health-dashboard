#!/usr/bin/env python3
"""render-check.py — screenshot dist/shop.html headless to verify the build.
Requires: pip install playwright && playwright install chromium
Usage:    python3 tools/build.py && python3 tools/render-check.py
Output:   dist/render-check.png
"""
import os
from playwright.sync_api import sync_playwright
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
target='file://'+os.path.join(ROOT,'dist','shop.html')
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={'width':1280,'height':1200})
    pg.goto(target, wait_until='networkidle')
    pg.wait_for_timeout(500)
    pg.screenshot(path=os.path.join(ROOT,'dist','render-check.png'), full_page=False)
    b.close()
print('Wrote dist/render-check.png')
