#!/usr/bin/env python3
"""serve.py — serve the source tree locally so the page can load its CSS/JS/images.
Opening index.html via file:// will NOT load the JS modules in some browsers,
so use this during development.

Usage:  python3 tools/serve.py   ->  http://localhost:8000/index.html
"""
import http.server, socketserver, os
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
PORT=int(os.environ.get('PORT','8000'))
with socketserver.TCPServer(('',PORT), http.server.SimpleHTTPRequestHandler) as h:
    print(f'Serving at http://localhost:{PORT}/index.html  (Ctrl+C to stop)')
    h.serve_forever()
