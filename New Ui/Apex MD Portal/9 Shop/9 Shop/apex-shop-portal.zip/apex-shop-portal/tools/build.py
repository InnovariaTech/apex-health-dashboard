#!/usr/bin/env python3
"""
build.py — bundle the modular source into a single self-contained dist/shop.html.

Inlines css/styles.css, the four js/ modules, and re-embeds every image in
assets/images/ as a base64 data URI. The output is a fully portable single
HTML file (no external files except the Google Fonts <link>), identical in
behavior to the source tree.

Usage:  python3 tools/build.py
Output: dist/shop.html
"""
import re, base64, os, sys

ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def rd(p):
    with open(os.path.join(ROOT,p),encoding='utf-8') as f: return f.read()

MIME={'jpg':'image/jpeg','jpeg':'image/jpeg','png':'image/png','webp':'image/webp','gif':'image/gif'}

html=rd('index.html')

# 1) inline CSS
css=rd('css/styles.css')
html=html.replace('<link rel="stylesheet" href="css/styles.css">',
                  '<style>\n'+css+'\n</style>')

# 2) inline JS modules (single <script>, preserve load order)
order=['js/icons.js','js/photo.js','js/data.js','js/render.js']
combined='\n'.join(rd(p) for p in order)
html=re.sub(r'<!-- App modules.*?</script>\s*(?=</body>|$)',
            lambda m: '<script>\n'+combined+'\n</script>\n', html, flags=re.S)

# 3) re-embed images as data URIs
cache={}
def datauri(rel):
    if rel in cache: return cache[rel]
    ext=rel.rsplit('.',1)[-1].lower()
    with open(os.path.join(ROOT,rel),'rb') as f: b=f.read()
    uri='data:'+MIME.get(ext,'application/octet-stream')+';base64,'+base64.b64encode(b).decode()
    cache[rel]=uri; return uri
def repl(m):
    return datauri(m.group(0))
html=re.sub(r'assets/images/[\w.\-]+\.(?:jpg|jpeg|png|webp|gif)', repl, html)

os.makedirs(os.path.join(ROOT,'dist'),exist_ok=True)
out=os.path.join(ROOT,'dist','shop.html')
with open(out,'w',encoding='utf-8') as f: f.write(html)
print('Built %s  (%.2f MB, %d images inlined)'%(out, len(html)/1e6, len(cache)))
