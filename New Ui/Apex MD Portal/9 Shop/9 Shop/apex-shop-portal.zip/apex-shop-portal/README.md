# Apex MD — Shop Page

Patient-portal **Shop** page for Apex MD / Apex Fit. This package contains the
full, editable source (HTML, CSS, JS, data, images) plus a one-command build
that bundles everything into a single self-contained `dist/shop.html`.

---

## Quick start

```bash
# 1. Run it locally (serves the source tree so JS modules + images load)
python3 tools/serve.py
#    -> open http://localhost:8000/index.html

# 2. Build the single-file deployable
python3 tools/build.py
#    -> writes dist/shop.html  (one portable file, all images inlined)
```

> Open `index.html` through the local server (step 1), **not** by double-clicking
> the file — browsers block `file://` JS modules and local image loads.

---

## Project structure

```
apex-shop-portal/
├── index.html            # Page shell: <head>, sidebar, tabs, mount point
├── css/
│   └── styles.css        # All styles (design tokens, layout, cards, sections)
├── js/
│   ├── icons.js          # Inline SVG icons + SVG product imagery (vials, kits)
│   ├── photo.js          # PHOTO map: keys -> assets/images/* paths + tile bg
│   ├── data.js           # Catalog: product arrays, TABS, ACC color map
│   └── render.js         # card()/section()/render + interactions (init)
├── assets/
│   └── images/           # All product / poster / logo images (jpg + png)
├── tools/
│   ├── build.py          # Bundle -> dist/shop.html (inlines css/js + images)
│   ├── serve.py          # Local dev server
│   └── render-check.py   # Headless screenshot of the build (Playwright)
├── dist/                 # Build output (shop.html) — generated
└── README.md
```

Load order of the JS modules (set in `index.html`) matters:
`icons.js → photo.js → data.js → render.js`
(`data.js` references `PHOTO` from `photo.js`; `render.js` reads `TABS` from `data.js`).

---

## How the page is built

The catalog is **data-driven**. Everything visible is generated from arrays in
`js/data.js` and rendered by `js/render.js`.

- **Tabs & sections** — `TABS` (in `data.js`) defines each tab and the sections
  inside it. Each section has `{id, accent, badge, title, sub, products}`.
- **Products** — each section points at a product array (`wl`, `trt`, `hrt`,
  `peptides`, `peptideBlends`, `labdx`, `supplements`, `programs`, `training`).
- **Accent colors** — `ACC` maps an accent name to a CSS color. A section's
  `accent` drives both its top bar and its badge bubble.
  Available: `blue, purple, teal, pink, orange, green, red, grey, black`.
- **Images** — `js/photo.js` (`PHOTO`) maps a key to `{src, bg}` where `src` is
  a path into `assets/images/` and `bg` is the tile background color. Products
  reference images via `img: PHOTO.<key>.src` and `tile: PHOTO.<key>.bg`.

### Common edits

| Task | Where |
|------|-------|
| Change a price | the product object in `js/data.js` (`price:'$249'`) |
| Change a description / name | the product object in `js/data.js` |
| Swap a product image | replace the file in `assets/images/`, keep the same name (or update the path in `js/photo.js`) |
| Recolor a section | the section's `accent` in `TABS` (`js/data.js`) |
| Add a product | add an object to the relevant array in `js/data.js`; add its image to `assets/images/` and a `PHOTO` entry in `js/photo.js` |
| Layout / spacing / colors | `css/styles.css` |

### Notes on the Fitness Programs posters
- Poster tiles use a fixed **3-wide-to-4-tall-ish** image box locked to one
  aspect ratio (`#sec-programs .prod-img { aspect-ratio: 0.633 }` in
  `styles.css`) so every tile is the same size and the images line up.
- Posters are pre-normalized to that aspect (padded with black, which is
  invisible against their black backgrounds) and use `object-fit: cover`, so
  each fills its tile edge-to-edge with no letterbox bars.
- To add a new poster, export it at the same aspect (**~3:4 / 0.633**, e.g.
  900×1421 or 1200×1896) on a black background.

---

## Build details

`tools/build.py` produces `dist/shop.html` by:
1. inlining `css/styles.css` into a `<style>` block,
2. concatenating the four JS modules (in load order) into one `<script>`,
3. re-embedding every `assets/images/*` reference as a base64 data URI.

The result is a single file you can host anywhere or open directly — the only
external dependency is the Google Fonts `<link>` (Inter + JetBrains Mono) in
`index.html`. To fully offline-proof it, self-host those two fonts and swap the
link for local `@font-face` rules.

## Tech
Plain HTML/CSS/JS — no framework, no build dependencies beyond Python 3
(standard library) for the tools. Playwright is optional, only for
`render-check.py`.
