/* ===== Apex MD Shop — Render & interaction logic =====
   Auto-generated module. Edit freely; run tools/build.py to bundle. */

/* ---------------- Render ---------------- */
function card(p, planIconKey){
  if(p.type==='intro'){
    return `<article class="card intro-card">
    <div class="prod-img prod-img--photo"><img class="prod-fill fill-cover" src="${p.img}" alt=""></div>
    <div class="card-body">
      <h4 class="intro-title">${p.lead}<br><span class="intro-accent">${p.lead2}</span></h4>
      <span class="intro-rule"></span>
      <p class="pdesc">${p.desc}</p>
      <div class="card-foot"><button class="cta-btn intro-btn">${p.cta} ${ARROW}</button></div>
    </div>
  </article>`;
  }
  let img, imgCls='prod-img', imgStyle='';
  if(p.img){ const poster=p.fit==='poster'; const collage=p.fit==='collage'; img = `<img class="prod-fill${p.fit==='cover'?' fill-cover':''}${poster?' fill-poster':''}${collage?' fill-collage':''}" src="${p.img}" alt="${p.name}">`; imgCls='prod-img prod-img--photo'+(poster?' prod-img--poster':'')+(collage?' prod-img--collage':''); imgStyle=` style="background:${p.tile||'#ececea'}"`; }
  else if(p.type==='vial') img = vialSVG(p.name, p.kind||'');
  else if(p.type==='bottle') img = bottleSVG(p.name, p.kind||'');
  else if(p.type==='kit') img = kitSVG(p.name);
  else img = `<div class="plan-mark" style="background:${ACC[planIcon_accent]}">${PLAN_ICON[planIconKey]||PLAN_ICON.programs}</div>`;
  const badge = p.badge ? `<span class="pbadge pbadge--${p.badge.color}">${p.badge.text}</span>` : '';
  const per = p.per ? `<span class="per">${p.per}</span>` : '';
  const tag = p.clickable ? 'a' : 'article';
  const linkAttr = p.clickable ? ' href="#" onclick="return false" role="button"' : '';
  return `<${tag} class="card${p.clickable?' card-clickable':''}${p.soon?' is-soon':''}"${linkAttr}>
    <div class="${imgCls}"${imgStyle}>${img}</div>
    <div class="card-body">
      <div class="card-top"><h4 class="pname">${p.name}${p.topPrice ? ` - ${p.topPrice}` : ''}</h4>${badge}</div>${p.topNote ? `<div style="font-weight:500;font-size:12px;color:var(--ink-3);letter-spacing:0;margin-top:2px">${p.topNote}</div>` : ''}
      <p class="pdesc">${p.desc}</p>
      ${p.features ? `<button class="readmore-btn" aria-expanded="false" onclick="toggleReadMore(this)"><span class="rm-label">See Details</span><svg class="rm-chev" viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg></button><div class="readmore-wrap"><div style="margin:2px 0 4px;">${p.features.map(f=>`<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;padding:9px 0;border-top:1px solid #ececec;"><div><div style="font-weight:700;color:var(--ink);font-size:13px;line-height:1.3;">${f.name}</div><div style="color:var(--ink-2);font-size:12px;line-height:1.35;margin-top:3px;">${f.desc}</div></div><span style="color:${f.inc===false?'var(--ink-3)':'var(--ink)'};font-weight:700;font-size:14px;line-height:1.3;flex:none;">${f.inc===false?'—':'✓'}</span></div>`).join('')}</div></div>` : ''}
      ${p.soon ? `<div class="card-foot soon"><span class="soon-date">${CAL} ${p.soon}</span></div>` : p.cta ? `<div class="card-foot"><button class="cta-btn">${p.cta}</button></div>` : `<div class="card-foot"><div class="price">${p.price}${per}</div><span class="shop-link">Shop ${EXT}</span></div>`}
    </div>
  </${tag}>`;
}
function toggleReadMore(btn){
  const wrap = btn.nextElementSibling;
  const open = !wrap.classList.contains('open');
  wrap.classList.toggle('open', open);
  btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  btn.querySelector('.rm-label').textContent = open ? 'Hide Details' : 'See Details';
  wrap.style.maxHeight = open ? (wrap.scrollHeight + 'px') : '0px';
}
let planIcon_accent='red';
function section(s, planIconKey){
  planIcon_accent = s.accent;
  const acc = ACC[s.accent];
  const action = s.action ? `<button class="quiz-btn">${s.action} ${EXT}</button>` : '';
  return `<section class="cat" id="sec-${s.id}" style="--acc:${acc}">
    <div class="cat-bar"></div>
    <div class="cat-head">
      <div>
        <span class="cat-badge" style="background:${acc}">${s.badge}</span>
        <h2 class="cat-title">${s.title}</h2>
        <p class="cat-sub">${s.sub}</p>
      </div>
      ${action}
    </div>
    <div class="grid">${s.products.map(p=>card(p, planIconKey)).join('')}</div>
  </section>`;
}

const tabsEl = document.getElementById('tabs');
const panelsEl = document.getElementById('panels');

tabsEl.innerHTML = TABS.map((t,i)=>`<button class="tab${i===0?' active':''}" data-tab="${t.id}">${t.icon}${t.label}</button>`).join('');

panelsEl.innerHTML = TABS.map((t,i)=>{
  const pills = t.pills ? `<div class="pills" data-pills="${t.id}">${t.pills.map((p,j)=>`<button class="pill${j===0?' active':''}" data-sec="sec-${p.sec}">${p.label}</button>`).join('')}</div>` : '';
  const secs = t.sections.map(s=>section(s, t.planIcon)).join('');
  return `<div class="panel${i===0?' active':''}" data-panel="${t.id}">${pills}${secs}</div>`;
}).join('');

/* Tab switching */
tabsEl.querySelectorAll('.tab').forEach(btn=>{
  btn.addEventListener('click',()=>{
    tabsEl.querySelectorAll('.tab').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    const id = btn.dataset.tab;
    panelsEl.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active', p.dataset.panel===id));
    window.scrollTo({top:0,behavior:'smooth'});
  });
});

/* Filter pills -> smooth scroll + active state */
panelsEl.querySelectorAll('.pill').forEach(pill=>{
  pill.addEventListener('click',()=>{
    pill.parentElement.querySelectorAll('.pill').forEach(p=>p.classList.remove('active'));
    pill.classList.add('active');
    const el = document.getElementById(pill.dataset.sec);
    if(el){ const y = el.getBoundingClientRect().top + window.scrollY - 84; window.scrollTo({top:y,behavior:'smooth'}); }
  });
});

/* Scroll-spy for medical pills */
const medPills = panelsEl.querySelector('[data-pills="medical"]');
if(medPills){
  const map = {};
  medPills.querySelectorAll('.pill').forEach(p=>{ map[p.dataset.sec]=p; });
  const obs = new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(e.isIntersecting && map[e.target.id]){
        medPills.querySelectorAll('.pill').forEach(p=>p.classList.remove('active'));
        map[e.target.id].classList.add('active');
      }
    });
  },{rootMargin:'-90px 0px -70% 0px',threshold:0});
  Object.keys(map).forEach(id=>{ const el=document.getElementById(id); if(el) obs.observe(el); });
}
