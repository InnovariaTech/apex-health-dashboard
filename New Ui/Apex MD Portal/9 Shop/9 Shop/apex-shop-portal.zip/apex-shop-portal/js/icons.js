/* ===== Apex MD Shop — Icons & SVG product imagery =====
   Auto-generated module. Edit freely; run tools/build.py to bundle. */


/* ---------------- Icons ---------------- */
const CAL = '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 9h18M8 3v4M16 3v4"/></svg>';
const EXT = '<svg viewBox="0 0 24 24"><path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M18 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h5"/></svg>';
const ARROW = '<svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
const I = {
  medical:'<svg viewBox="0 0 24 24"><rect x="8.3" y="2.5" width="7.4" height="3.4" rx="1.3"/><path d="M9.3 5.9v1.3l-1.1 1.1A2 2 0 0 0 7.6 9.7V19a2 2 0 0 0 2 2h4.8a2 2 0 0 0 2-2V9.7a2 2 0 0 0-.6-1.4l-1.1-1.1V5.9"/><path d="M12 12.3v4M10 14.3h4"/></svg>',
  supplements:'<svg viewBox="0 0 24 24"><path d="M10.5 20.5a6 6 0 0 1-8.5-8.5l7-7a6 6 0 0 1 8.5 8.5z"/><path d="M8.5 8.5l7 7"/></svg>',
  memberships:'<svg viewBox="0 0 24 24"><circle cx="12" cy="6" r="3.3"/><path d="M5 21v-1a7 7 0 0 1 14 0v1"/><path d="M9.2 12.4v2.1a2.8 2.8 0 0 0 5.6 0v-1"/><circle cx="16.8" cy="14" r="1.4"/></svg>',
  programs:'<svg viewBox="0 0 24 24"><path d="M4 19h12.5a1.5 1.5 0 0 0 1.5-1.5V7.5a2.5 2.5 0 0 0-5 0V10a4.5 4.5 0 0 1-4.5 4.5H4Z"/><path d="M4 14.5c0-3 2-5.5 5-5.5"/><path d="M13.5 7.5v-2M16 7.5v-2"/></svg>',
  training:'<svg viewBox="0 0 24 24"><path d="M4 9v6M7 7v10M17 7v10M20 9v6M7 12h10"/></svg>'
};
const PLAN_ICON = {
  memberships:'<svg viewBox="0 0 24 24"><circle cx="12" cy="6" r="3.3"/><path d="M5 21v-1a7 7 0 0 1 14 0v1"/><path d="M9.2 12.4v2.1a2.8 2.8 0 0 0 5.6 0v-1"/><circle cx="16.8" cy="14" r="1.4"/></svg>',
  programs:'<svg viewBox="0 0 24 24"><path d="M4 19h12.5a1.5 1.5 0 0 0 1.5-1.5V7.5a2.5 2.5 0 0 0-5 0V10a4.5 4.5 0 0 1-4.5 4.5H4Z"/><path d="M4 14.5c0-3 2-5.5 5-5.5"/><path d="M13.5 7.5v-2M16 7.5v-2"/></svg>',
  training:'<svg viewBox="0 0 24 24"><path d="M4 9v6M7 7v10M17 7v10M20 9v6M7 12h10"/></svg>'
};

/* ---------------- Product imagery (SVG, self-contained) ---------------- */
const MARK = (cx,y,scale=1)=>{
  const p=`M${cx-9} ${y} L${cx-4} ${y-7} L${cx-1} ${y-3} L${cx+2} ${y-8} L${cx+5} ${y-3} L${cx+8} ${y-7} L${cx+13} ${y} Z`;
  return `<path d="${p}" fill="#D30603"/>`;
};
function labelBlock(cx, topY, kind, name){
  const fs = name.length>13 ? 5 : name.length>10 ? 6 : 7;
  return `
    ${MARK(cx, topY+10)}
    <text x="${cx}" y="${topY+20}" text-anchor="middle" font-family="Inter,sans-serif" font-size="7" font-weight="800" fill="#16181c" letter-spacing="0.4">APEX MD</text>
    <line x1="${cx-15}" y1="${topY+25}" x2="${cx+15}" y2="${topY+25}" stroke="#D30603" stroke-width="1"/>
    <text x="${cx}" y="${topY+33}" text-anchor="middle" font-family="Inter,sans-serif" font-size="4.4" fill="#9aa0ab" letter-spacing="0.6">${kind}</text>
    <text x="${cx}" y="${topY+43}" text-anchor="middle" font-family="Inter,sans-serif" font-size="${fs}" font-weight="700" fill="#16181c">${name}</text>`;
}
function vialSVG(name, kind){
  return `<svg class="prod-svg" viewBox="0 0 110 180" xmlns="http://www.w3.org/2000/svg" aria-label="${name}">
    <ellipse cx="55" cy="170" rx="26" ry="5" fill="#000" opacity="0.07"/>
    <rect x="38" y="10" width="34" height="19" rx="4" fill="#C0241E"/>
    <rect x="38" y="10" width="34" height="7" rx="4" fill="#DA453F"/>
    <rect x="36" y="28" width="38" height="11" rx="2" fill="#C7CBD1"/>
    <rect x="36" y="28" width="38" height="4" fill="#E2E5E9"/>
    <rect x="42" y="38" width="26" height="8" fill="#E7EEF2"/>
    <path d="M30 46 H80 V150 a12 12 0 0 1 -12 12 H42 a12 12 0 0 1 -12 -12 Z" fill="#E9F1F6"/>
    <path d="M30 122 H80 V150 a12 12 0 0 1 -12 12 H42 a12 12 0 0 1 -12 -12 Z" fill="#D6E5EE"/>
    <rect x="34" y="50" width="6" height="106" rx="3" fill="#ffffff" opacity="0.65"/>
    <rect x="71" y="50" width="7" height="106" rx="3" fill="#C0D2DC" opacity="0.6"/>
    <rect x="27" y="84" width="56" height="58" rx="3" fill="#ffffff" stroke="#E4E4E4"/>
    ${labelBlock(55, 90, kind, name)}
  </svg>`;
}
function bottleSVG(name, kind){
  return `<svg class="prod-svg" viewBox="0 0 110 180" xmlns="http://www.w3.org/2000/svg" aria-label="${name}">
    <ellipse cx="55" cy="170" rx="28" ry="5" fill="#000" opacity="0.07"/>
    <rect x="38" y="12" width="34" height="15" rx="3" fill="#C0241E"/>
    <rect x="38" y="12" width="34" height="5" rx="3" fill="#DA453F"/>
    <rect x="44" y="26" width="22" height="9" fill="#ECECE9"/>
    <path d="M30 35 H80 V152 a8 8 0 0 1 -8 8 H38 a8 8 0 0 1 -8 -8 Z" fill="#F4F4F1" stroke="#E2E2DE"/>
    <rect x="34" y="40" width="6" height="116" rx="3" fill="#ffffff" opacity="0.7"/>
    <rect x="27" y="70" width="56" height="76" rx="3" fill="#ffffff" stroke="#E6E6E2"/>
    ${labelBlock(55, 80, kind, name)}
  </svg>`;
}
function kitSVG(name){
  return `<svg class="prod-svg" viewBox="0 0 130 180" xmlns="http://www.w3.org/2000/svg" aria-label="${name}">
    <ellipse cx="65" cy="168" rx="40" ry="5" fill="#000" opacity="0.07"/>
    <rect x="22" y="46" width="86" height="116" rx="8" fill="#ffffff" stroke="#E2E2DE"/>
    <rect x="22" y="46" width="86" height="34" rx="8" fill="#D30603"/>
    <rect x="22" y="70" width="86" height="10" fill="#D30603"/>
    <path d="M${65-9} 66 L${65-4} 59 L${65-1} 63 L${65+2} 58 L${65+5} 63 L${65+8} 59 L${65+13} 66 Z" fill="#fff"/>
    <text x="65" y="78" text-anchor="middle" font-family="Inter,sans-serif" font-size="9" font-weight="800" fill="#ffffff" letter-spacing="0.5">APEX MD</text>
    <text x="65" y="100" text-anchor="middle" font-family="Inter,sans-serif" font-size="5.5" fill="#9aa0ab" letter-spacing="1">AT-HOME LAB KIT</text>
    <line x1="40" y1="108" x2="90" y2="108" stroke="#E2E2DE" stroke-width="1"/>
    <text x="65" y="128" text-anchor="middle" font-family="Inter,sans-serif" font-size="${name.length>18?7:8.5}" font-weight="700" fill="#16181c">${name}</text>
    <rect x="40" y="140" width="50" height="8" rx="4" fill="#F1F1EE"/>
  </svg>`;
}

/* ---------------- Catalog data ---------------- */
